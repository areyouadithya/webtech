import java.util.Scanner;
import java.util.random;
import java.util.ArrayList;
import javax.swing.*;

public class file_name {
    public static void main(String args[]){

        //user input
        Scanner ip = new Scanner(System.in);
        /*
         *  nextBoolean()	Reads a boolean value from the user
            nextByte()	Reads a byte value from the user
            nextDouble()	Reads a double value from the user
            nextFloat()	Reads a float value from the user
            nextInt()	Reads a int value from the user
            nextLine()	Reads a String value from the user
            nextLong()	Reads a long value from the user
            nextShort()	Reads a short value from the user
         */
        // format
        int integer;
        integer = ip.nextInt();
        ip.close();
        //printing output
        System.out.println(" ");

        //string
        String s;
        s.substring(/*begin index*/, /*end index */);
        s.valueOf(/*integer to be typecasted */);


        //math.random function

         int random = (int)(Math.random() * max-min+1) + min;
         int random1 = random.nextInt(/*boundary */); /*range: 0 to boundary -1 */

         //format

        System.out.printf("Volume of the sphere: %.4f%n", Volume);

        //math

        int r;
        Math.pow(r, 3); // r^3
        Math.PI;
        Math.sin(r);
        Math.cos(r);

        //ArrayList

        ArrayList<String> nameList = new ArrayList<String>();
        nameList.add("James");
        nameList.add("Catherine");
        nameList.add(2,"Mary");
        nameList.size(); //returns 2
        nameList.get(1);
        System.out.println(nameList); // [James, Catherine]
        nameList.remove(1);
        nameList.set(1, "Becky");

        //string
        String s = "Welcome";
        Strinf s= new String("Welcome");
        char ch[] = {'h','e','y'};
        String s = new String(ch); //ch array to string

        s.length();
        s.substring(/*begin index */,/*end index */);
        s.charAt(/*index */);
        s.contains(/*sequence of chars */);
        s.getChars(/*begin index */,/*end index */,/*name of ch array */,0);   //coverts string s to ch array
        s.replace('a','e');
        s.toLowerCase();
        s.toUpperCase();
    

    }
}