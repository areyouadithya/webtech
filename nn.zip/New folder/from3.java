import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class from3 extends JFrame {
    private JTextField nameField;
    private JPasswordField passwordField;
    private JTextField dobField;
    private JButton submitButton;

    public from3() {
        setTitle("User Registration Form");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        nameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        dobField = new JTextField(20);
        submitButton = new JButton("Submit");

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (validateForm()) {
                    JOptionPane.showMessageDialog(from3.this, "Registration Successful!");
                } else {
                    JOptionPane.showMessageDialog(from3.this, "Please correct the following:");
                }
            }
        });

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(4, 2));
        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Password (more than 8 characters):"));
        formPanel.add(passwordField);
        formPanel.add(new JLabel("Date of Birth (born before 2004, yyyy-mm-dd):"));
        formPanel.add(dobField);
        formPanel.add(new JLabel(""));
        formPanel.add(submitButton);

        add(formPanel);
    }

    private boolean validateForm() {
        String name = nameField.getText();
        String password = new String(passwordField.getPassword());
        String dobText = dobField.getText();

        // Validate name (no symbols)
        if (!name.matches("^[a-zA-Z ]+$")) {
            JOptionPane.showMessageDialog(this, "Invalid name format. Use only letters and spaces.");
            return false;
        }

        // Validate password (more than 8 characters)
        if (password.length() <= 8) {
            JOptionPane.showMessageDialog(this, "Password must be more than 8 characters.");
            return false;
        }

        // Validate date of birth (born before 2004)
        try {
            String[] parts = dobText.split("-");
            int year = Integer.parseInt(parts[0]);
            if (year >= 2004) {
                JOptionPane.showMessageDialog(this, "You must be born before 2004.");
                return false;
            }
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException ex) {
            JOptionPane.showMessageDialog(this, "Invalid date of birth format. Use yyyy-mm-dd.");
            return false;
        }

        return true;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                from3 app = new from3();
                app.setVisible(true);
            }
        });
    }
}
