import javax.swing.*;
import java.awt.*;

public class MyAnimation extends JPanel{
    int x=0;
    int y=0;
    int ballWidth=50;
    int ballHeight=50;
    int xmax, ymax;
    int speedX=10;
    int speedY=10;

    MyAnimation(int w,int h){
        this.xmax=w-ballWidth;
        this.ymax=h-ballHeight;
    }

    @Override
    public void paint(Graphics g){
        super.paint(g);

        g.setColor(Color.red);
        g.fillOval(x,y,ballWidth,ballHeight);

        if(x>xmax || x<0){
            speedX=-speedX;
        }
        if(y>ymax || y<0){
            speedY=-speedY;
        }

        x=x+speedX;
        y=y+speedY;

        try {
            Thread.sleep(10);
        } catch (Exception e) {
            // TODO: handle exception
        }

        repaint();
    }
}