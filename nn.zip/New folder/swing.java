import java.awt.event.*;  
import javax.swing.*;  

public class swing {  
public static void main(String[] args) {  
JFrame f=new JFrame("Title of the frame");//creating instance of JFrame  
          
JButton b=new JButton("click");//creating instance of JButton  
JLabel l =new JLabel("Label Name");
JTextField t = new JTextField("Welcome to Javatpoint.");
JTextArea area=new JTextArea("Welcome to javatpoint");  
JPasswordField pass = new JPasswordField();   
area.setBounds(10,30, 200,200);  
f.add(area);
l.setBounds(10, 10, 10, 10);
b.setBounds(130,100,100, 40);//x axis, y axis, width, height  
t.setBounds();
f.add(l);         
f.add(b);//adding button in JFrame  
f.add(t);
          
f.setSize(1000,1000);//400 width and 500 height  
f.setLayout(null);//using no layout managers  
f.setVisible(true);//making the frame visible  
}  
}  