import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class form extends JFrame {
    private JTextField dobField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField resultField;

    public form() {
        setTitle("User Form with Calculator");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the form components
        JLabel dobLabel = new JLabel("Date of Birth:");
        dobField = new JTextField(10);

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField(10);

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField(10);

        JButton calculateButton = new JButton("Calculate");
        resultField = new JTextField(10);
        resultField.setEditable(false);

        // Create the calculator panel
        JPanel calculatorPanel = new JPanel();
        calculatorPanel.add(new JLabel("Calculator: "));
        JTextField numField1 = new JTextField(5);
        JTextField numField2 = new JTextField(5);
        JComboBox<String> operatorCombo = new JComboBox<>(new String[]{"+", "-", "*", "/"});
        JButton calculateButton2 = new JButton("Calculate");
        calculatorPanel.add(numField1);
        calculatorPanel.add(operatorCombo);
        calculatorPanel.add(numField2);
        calculatorPanel.add(calculateButton2);
        calculatorPanel.add(resultField);

        // Add components to the frame
        setLayout(new FlowLayout());
        add(dobLabel);
        add(dobField);
        add(usernameLabel);
        add(usernameField);
        add(passwordLabel);
        add(passwordField);
        add(calculateButton);
        add(calculatorPanel);

        // Add ActionListener for the Calculate button
        calculateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calculate();
            }
        });

        // Add ActionListener for the Calculator Calculate button
        calculateButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                calculateArithmetic(numField1.getText(), numField2.getText(), (String) operatorCombo.getSelectedItem());
            }
        });
    }

    private void calculate() {
        String dob = dobField.getText();
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        // Perform some action with the input data (you can customize this part)
        String result = "DOB: " + dob + ", Username: " + username + ", Password: " + password;
        resultField.setText(result);
    }

    private void calculateArithmetic(String num1, String num2, String operator) {
        try {
            double operand1 = Double.parseDouble(num1);
            double operand2 = Double.parseDouble(num2);
            double result;

            switch (operator) {
                case "+":
                    result = operand1 + operand2;
                    break;
                case "-":
                    result = operand1 - operand2;
                    break;
                case "*":
                    result = operand1 * operand2;
                    break;
                case "/":
                    if (operand2 != 0) {
                        result = operand1 / operand2;
                    } else {
                        resultField.setText("Error: Division by zero");
                        return;
                    }
                    break;
                default:
                    resultField.setText("Invalid operator");
                    return;
            }

            resultField.setText(Double.toString(result));
        } catch (NumberFormatException ex) {
            resultField.setText("Invalid input");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                form app = new form();
                app.setVisible(true);
            }
        });
    }
}
