import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


class MyFrame extends JFrame implements ActionListener{
    JTextField t1;
    JPasswordField t2;
    MyFrame(){
        setTitle("LoginForm");
        setSize(400,600);
       // f.setDefaultCloseOperation(EXIT_ON_CLOSE);
       setLayout(new FlowLayout());

        JLabel l1 = new JLabel("Username:");
        JLabel l2 = new JLabel("Password:");

       // l1.setBounds(10, 50, 100, 20);
       // l2.setBounds(10, 70, 100, 20);
        
        t1 = new JTextField(20);
       // t1.setBounds(120,50,100,20);
        JPasswordField t2 = new JPasswordField(20);
       // t2.setBounds(120,70,100,20);

       JButton login = new JButton("Login");
       login.addActionListener(this);

        
        add(l1);
        add(t1);
        add(l2);
        add(t2);
        add(login);
        
        
        
        
        setVisible(true);
    }
    public void actionPerformed(ActionEvent e){
        System.out.println("Username: "+t1.getText());
        //System.out.println("Password: "+t2.getText());
    }
}

public class LoginForm{
    public static void main(String[] args){
        MyFrame f = new MyFrame();
    }
}