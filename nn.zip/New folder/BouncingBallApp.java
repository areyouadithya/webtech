import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BouncingBallApp extends JFrame {
    private int ballX = 50;
    private int ballY = 50;
    private int ballDiameter = 50;
    private int xDirection = 1;
    private int yDirection = 1;

    public BouncingBallApp() {
        setTitle("Bouncing Ball");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Timer timer = new Timer(10, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Update the ball's position
                ballX += xDirection;
                ballY += yDirection;

                // Bounce the ball off the edges
                if (ballX <= 0 || ballX + ballDiameter >= getWidth()) {
                    xDirection *= -1;
                }
                if (ballY <= 0 || ballY + ballDiameter >= getHeight()) {
                    yDirection *= -1;
                }

                repaint(); // Request a repaint of the panel
            }
        });

        timer.start();
    }

    public void paint(Graphics g) {
        super.paint(g);
        g.setColor(Color.BLUE);
        g.fillOval(ballX, ballY, ballDiameter, ballDiameter);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                BouncingBallApp app = new BouncingBallApp();
                app.setVisible(true);
            }
        });
    }
}
