import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormatSymbols; // Corrected import
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Calender extends JFrame {
    private JLabel monthLabel;
    private JPanel calendarPanel;
    private int currentMonth, currentYear;

    public Calender() {
        setTitle("Java Swing Calendar");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        monthLabel = new JLabel("", JLabel.CENTER);
        calendarPanel = new JPanel(new GridLayout(0, 7));

        JButton prevButton = new JButton("Previous");
        prevButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentMonth--;
                if (currentMonth < 0) {
                    currentMonth = 11;
                    currentYear--;
                }
                updateCalendar();
            }
        });

        JButton nextButton = new JButton("Next");
        nextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                currentMonth++;
                if (currentMonth > 11) {
                    currentMonth = 0;
                    currentYear++;
                }
                updateCalendar();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(prevButton);
        buttonPanel.add(monthLabel);
        buttonPanel.add(nextButton);

        add(buttonPanel, BorderLayout.NORTH);
        add(calendarPanel, BorderLayout.CENTER);

        // Get the current date
        Calendar today = Calendar.getInstance();
        currentMonth = today.get(Calendar.MONTH);
        currentYear = today.get(Calendar.YEAR);

        updateCalendar();
    }

    private void updateCalendar() {
        calendarPanel.removeAll();
        Calendar cal = new GregorianCalendar(currentYear, currentMonth, 1);
        int daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

        monthLabel.setText(new DateFormatSymbols().getMonths()[currentMonth] + " " + currentYear);

        for (int i = 1; i <= daysInMonth; i++) {
            JButton dayButton = new JButton(Integer.toString(i));
            calendarPanel.add(dayButton);
        }

        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Calender app = new Calender();
                app.setVisible(true);
            }
        });
    }
}
