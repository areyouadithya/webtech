import javax.swing.JFrame;
import java.awt.*;

public class BouncingBall extends JFrame {
    BouncingBall(){
        setSize(600,400);
        setTitle("Bouncing Ball");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        MyAnimation panel = new MyAnimation(500, 360);
        panel.setBackground(Color.black);
        add(panel);
    
    }

    public static void main(String[] args){
        new BouncingBall().setVisible(true);
    }
}
