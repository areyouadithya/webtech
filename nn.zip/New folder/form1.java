import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class form1 extends JFrame {
    public form1() {
        setTitle("Comprehensive Swing Form with Table");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a table with sample data
        String[] columnNames = {"ID", "Name", "Age"};
        Object[][] data = {
                {1, "John", 30},
                {2, "Alice", 25},
                {3, "Bob", 35}
        };
        JTable table = new JTable(data, columnNames);

        // Create a scroll pane to display the table with scrolling
        JScrollPane tableScrollPane = new JScrollPane(table);

        // Create a right-click context menu
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem editMenuItem = new JMenuItem("Edit");
        JMenuItem deleteMenuItem = new JMenuItem("Delete");
        popupMenu.add(editMenuItem);
        popupMenu.add(deleteMenuItem);

        // Add a mouse listener to display the context menu
        table.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    popupMenu.show(e.getComponent(), e.getX(), e.getY());
                }
            }

            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    popupMenu.show(e.getComponent(), e.getX(), e.getY());
                }
            }
        });

        // Create a submit button
        JButton submitButton = new JButton("Submit");

        // Create a panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(submitButton);

        // Create a panel for the table
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.add(tableScrollPane, BorderLayout.CENTER);

        // Add the button panel and table panel to the main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(tablePanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Add the main panel to the frame
        add(mainPanel);

        // Add an ActionListener to the submit button
        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Add your submission logic here
                JOptionPane.showMessageDialog(form1.this, "Form Submitted!");
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                form1 app = new form1();
                app.setVisible(true);
            }
        });
    }
}
